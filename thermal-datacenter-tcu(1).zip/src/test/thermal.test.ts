import { describe, it, expect } from "vitest";
import { deltaT, crc32 } from "@/lib/thermal";
import { FAMILIES, encodeFrame, verifyFrame } from "@/lib/tcu";

describe("thermal rules", () => {
  it("ΔT = heat*thick/cond", () => { expect(deltaT(10000, 0.01, 200)).toBeCloseTo(0.5); });
  it("CRC32 standard check value", () => { expect(crc32(new TextEncoder().encode("123456789"))).toBe(0xcbf43926); });
  it("frames verify and detect corruption", () => {
    const f = encodeFrame(FAMILIES[0]!, [21.5, 30]);
    expect(verifyFrame(f)).toBe(true);
    f[4] = f[4]! ^ 1;
    expect(verifyFrame(f)).toBe(false);
  });
});
