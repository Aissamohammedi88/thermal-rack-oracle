import { setSim, useSim } from "@/lib/sim-store";
import { CRACS, MATERIALS, deltaT, type MaterialId } from "@/lib/thermal";
import { Panel } from "./AppShell";

export function Gauge({ value, max = 90, label }: { value: number; max?: number; label: string }) {
  const x = Math.min(1, value / max);
  const a = Math.PI * (1 - x);
  const color = value > 55 ? "var(--destructive)" : value > 40 ? "var(--accent)" : "var(--success)";
  return (
    <div className="text-center">
      <svg viewBox="0 0 100 60" className="w-full max-w-40 mx-auto">
        <path d="M10 50 A40 40 0 0 1 90 50" fill="none" stroke="var(--muted)" strokeWidth="8" />
        <path d={`M10 50 A40 40 0 0 1 ${50 + 40 * Math.cos(a)} ${50 - 40 * Math.sin(a)}`} fill="none" stroke={color} strokeWidth="8" />
        <text x="50" y="48" textAnchor="middle" fill="var(--foreground)" fontSize="14" fontFamily="JetBrains Mono">{value.toFixed(1)}°</text>
      </svg>
      <div className="font-mono text-[10px] uppercase text-muted-foreground">{label}</div>
    </div>
  );
}

export function SimControls() {
  const s = useSim();
  const k = MATERIALS[s.material].k;
  const dt = deltaT(s.heat, s.thicknessMm / 1000, k);
  return (
    <Panel title="Paramètres du moteur thermique">
      <div className="space-y-4 text-sm">
        <label className="block">
          <div className="flex justify-between"><span>Charge thermique q</span><span className="font-mono text-primary">{s.heat.toLocaleString("fr")} W/m²</span></div>
          <input type="range" min={1000} max={60000} step={500} value={s.heat} onChange={(e) => setSim({ heat: +e.target.value })} className="w-full accent-primary" />
        </label>
        <label className="block">
          <div className="flex justify-between"><span>Épaisseur paroi L</span><span className="font-mono text-primary">{s.thicknessMm} mm</span></div>
          <input type="range" min={0.5} max={30} step={0.5} value={s.thicknessMm} onChange={(e) => setSim({ thicknessMm: +e.target.value })} className="w-full accent-primary" />
        </label>
        <div>
          <div className="mb-1">Matériau dissipateur (k)</div>
          <div className="grid grid-cols-2 gap-1">
            {(Object.keys(MATERIALS) as MaterialId[]).map((m) => (
              <button key={m} onClick={() => setSim({ material: m })}
                className={`rounded border px-2 py-1 text-left text-xs ${s.material === m ? "border-primary bg-primary/15 text-primary" : "border-border hover:bg-secondary"}`}>
                {MATERIALS[m].label}<span className="block font-mono text-muted-foreground">{MATERIALS[m].k} W/m·K</span>
              </button>
            ))}
          </div>
        </div>
        <div className="rounded bg-muted p-2 font-mono text-xs">
          ΔT = (q · L) / k = ({s.heat} × {(s.thicknessMm / 1000).toFixed(4)}) / {k}
          <div className={`text-lg ${dt > 20 ? "text-destructive" : "text-primary"}`}>ΔT = {dt.toFixed(3)} K</div>
        </div>
        <div>
          <div className="mb-1">Climatisation CRAC/CRAH — simuler une panne</div>
          <div className="grid grid-cols-2 gap-1">
            {CRACS.map((c, i) => {
              const down = s.failedAt[i] !== null;
              return (
                <button key={c.id} onClick={() => setSim((st) => ({ failedAt: st.failedAt.map((v, j) => (j === i ? (v === null ? st.tick : null) : v)) }))}
                  className={`rounded border px-2 py-1 font-mono text-xs ${down ? "border-destructive bg-destructive/20 text-destructive" : "border-success/50 text-success hover:bg-secondary"}`}>
                  {c.id} · {down ? "PANNE" : "OK"}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </Panel>
  );
}
