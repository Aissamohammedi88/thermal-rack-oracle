import { Link } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { startClock, useSim, setSim } from "@/lib/sim-store";
import { CRACS } from "@/lib/thermal";

const NAV = [
  { to: "/", label: "Cartographie" },
  { to: "/simulation", label: "Simulation" },
  { to: "/tcu", label: "HAL · TCU" },
  { to: "/flasher", label: "Payload & Flasher" },
  { to: "/code", label: "Intégration" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  useEffect(() => startClock(), []);
  const s = useSim();
  const failed = s.failedAt.filter((x) => x !== null).length;
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-border bg-sidebar/95 backdrop-blur">
        <div className="flex flex-wrap items-center gap-4 px-4 py-2">
          <div className="font-mono text-sm font-semibold tracking-widest text-primary">▣ THERMACORE·NOC</div>
          <nav className="flex flex-wrap gap-1">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} activeOptions={{ exact: true }}
                className="rounded px-3 py-1 text-sm font-semibold uppercase tracking-wide text-muted-foreground hover:bg-secondary hover:text-foreground"
                activeProps={{ className: "bg-secondary text-primary" }}>{n.label}</Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-3 font-mono text-xs">
            <span className="text-muted-foreground">T+{(s.tick / 2).toFixed(1)}s</span>
            {CRACS.map((c, i) => (
              <span key={c.id} className={s.failedAt[i] !== null ? "animate-pulse text-destructive" : "text-success"}>● {c.id}</span>
            ))}
            <button onClick={() => setSim({ running: !s.running })} className="rounded border border-border px-2 py-0.5 hover:bg-secondary">
              {s.running ? "❚❚ PAUSE" : "▶ RUN"}
            </button>
          </div>
        </div>
        {failed > 0 && (
          <div className="bg-destructive px-4 py-1 font-mono text-xs font-semibold text-destructive-foreground">
            ⚠ ALERTE : {failed} unité(s) de climatisation en panne — propagation de points chauds en cours
          </div>
        )}
      </header>
      <main className="p-4">{children}</main>
    </div>
  );
}

export function Panel({ title, children, className = "" }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded border border-border bg-card ${className}`}>
      <h2 className="border-b border-border px-3 py-1.5 font-mono text-xs uppercase tracking-widest text-muted-foreground">{title}</h2>
      <div className="p-3">{children}</div>
    </section>
  );
}
