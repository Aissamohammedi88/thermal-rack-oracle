export const SOURCES: { id: string; file: string; lang: string; code: string }[] = [
  { id: "bash", file: "orchestrate.sh", lang: "Bash", code: `#!/usr/bin/env bash
# ThermaCore — orchestration Linux Mint 21+/22
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; BUILD="$ROOT/build"; mkdir -p "$BUILD"

echo "[1/5] Dépendances"
sudo apt-get update -qq
sudo apt-get install -y build-essential nvidia-cuda-toolkit can-utils i2c-tools libibverbs-dev pkg-config
command -v cargo >/dev/null || curl https://sh.rustup.rs -sSf | sh -s -- -y
command -v zig   >/dev/null || sudo snap install zig --classic --beta

echo "[2/5] Kernel CUDA (nvcc)"
nvcc -O3 -arch=native -Xcompiler -fPIC -shared cuda/thermal_kernel.cu -o "$BUILD/libthermal.so"

echo "[3/5] Couche FFI C11 (gcc)"
gcc -std=c11 -O2 -Wall -fPIC -shared ffi/tcu_ffi.c -L"$BUILD" -lthermal -o "$BUILD/libtcuffi.so"

echo "[4/5] Module MMIO Zig + contrôleur Rust (cargo)"
zig build-lib -O ReleaseFast -dynamic zig/mmio.zig -femit-bin="$BUILD/libmmio.so"
RUSTFLAGS="-L $BUILD" cargo build --release --manifest-path controller/Cargo.toml

echo "[5/5] Lancement"
sudo modprobe can && sudo ip link set can0 up type can bitrate 1000000 dbitrate 5000000 fd on || true
export LD_LIBRARY_PATH="$BUILD:\${LD_LIBRARY_PATH:-}"
exec sudo -E "$ROOT/controller/target/release/tcu-controller" --config "$ROOT/tcu.toml"
` },
  { id: "cuda", file: "thermal_kernel.cu", lang: "CUDA C++", code: `#include <cuda_runtime.h>
#include <cstdint>

// ΔT = (heat * thick) / cond
__global__ void thermal_gradient(const float* heat, const float* thick, const float* cond,
                                 const float* inlet, float* out, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float dT = (heat[i] * thick[i]) / cond[i];
    out[i] = inlet[i] + dT;
}

__global__ void encode_centi(const float* t, int16_t* out, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) out[i] = (int16_t)__float2int_rn(t[i] * 100.0f);
}

extern "C" int tc_compute(const float* h, const float* L, const float* k, const float* in,
                          float* out, int16_t* enc, int n) {
    float *dh, *dL, *dk, *di, *dout; int16_t* denc; size_t sz = n * sizeof(float);
    cudaMalloc(&dh, sz); cudaMalloc(&dL, sz); cudaMalloc(&dk, sz); cudaMalloc(&di, sz);
    cudaMalloc(&dout, sz); cudaMalloc(&denc, n * sizeof(int16_t));
    cudaMemcpy(dh, h, sz, cudaMemcpyHostToDevice); cudaMemcpy(dL, L, sz, cudaMemcpyHostToDevice);
    cudaMemcpy(dk, k, sz, cudaMemcpyHostToDevice); cudaMemcpy(di, in, sz, cudaMemcpyHostToDevice);
    int b = 256, g = (n + b - 1) / b;
    thermal_gradient<<<g, b>>>(dh, dL, dk, di, dout, n);
    encode_centi<<<g, b>>>(dout, denc, n);
    cudaMemcpy(out, dout, sz, cudaMemcpyDeviceToHost);
    cudaMemcpy(enc, denc, n * sizeof(int16_t), cudaMemcpyDeviceToHost);
    cudaFree(dh); cudaFree(dL); cudaFree(dk); cudaFree(di); cudaFree(dout); cudaFree(denc);
    return (int)cudaGetLastError();
}
` },
  { id: "c", file: "tcu_ffi.c", lang: "C11", code: `#include <stdint.h>
#include <stddef.h>
#include <string.h>

static uint32_t table[256];
static void crc_init(void) {
    for (uint32_t n = 0; n < 256; n++) { uint32_t c = n;
        for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        table[n] = c; }
}
uint32_t tcu_crc32(const uint8_t* p, size_t len) {
    if (!table[1]) crc_init();
    uint32_t c = 0xFFFFFFFFu;
    while (len--) c = table[(c ^ *p++) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}
/* frame = header | len16 LE | int16 LE[n] | crc32 LE */
size_t tcu_encode(const uint8_t* hdr, size_t hl, const int16_t* t, uint16_t n, uint8_t* out) {
    size_t o = 0; memcpy(out, hdr, hl); o += hl;
    out[o++] = n & 0xFF; out[o++] = n >> 8;
    for (uint16_t i = 0; i < n; i++) { out[o++] = t[i] & 0xFF; out[o++] = (uint16_t)t[i] >> 8; }
    uint32_t c = tcu_crc32(out, o);
    for (int i = 0; i < 4; i++) out[o++] = (c >> (8 * i)) & 0xFF;
    return o;
}
` },
  { id: "rust", file: "controller/src/main.rs", lang: "Rust", code: `use std::{fs::OpenOptions, io::Write};

extern "C" {
    fn tc_compute(h: *const f32, l: *const f32, k: *const f32, i: *const f32,
                  out: *mut f32, enc: *mut i16, n: i32) -> i32;
    fn tcu_encode(hdr: *const u8, hl: usize, t: *const i16, n: u16, out: *mut u8) -> usize;
}

pub trait TcuDriver {
    fn name(&self) -> &'static str;
    fn header(&self) -> &'static [u8];
    fn open(&mut self) -> std::io::Result<()>;
    fn write_frame(&mut self, frame: &[u8]) -> std::io::Result<usize>;
    fn flash_register(&mut self, addr: u32, value: u32) -> std::io::Result<()>;
}

pub struct SerialTcu { path: &'static str, dev: Option<std::fs::File> }
impl TcuDriver for SerialTcu {
    fn name(&self) -> &'static str { "USB CDC-ACM" }
    fn header(&self) -> &'static [u8] { &[0x55, 0xAB] }
    fn open(&mut self) -> std::io::Result<()> {
        self.dev = Some(OpenOptions::new().read(true).write(true).open(self.path)?); Ok(())
    }
    fn write_frame(&mut self, f: &[u8]) -> std::io::Result<usize> { self.dev.as_mut().unwrap().write(f) }
    fn flash_register(&mut self, a: u32, v: u32) -> std::io::Result<()> {
        let mut b = vec![0xF1]; b.extend(a.to_le_bytes()); b.extend(v.to_le_bytes());
        self.write_frame(&b).map(|_| ())
    }
}

fn main() -> std::io::Result<()> {
    const N: usize = 42;
    let (h, l, k, i) = ([12_000f32; N], [0.005f32; N], [401f32; N], [21f32; N]);
    let (mut out, mut enc, mut frame) = ([0f32; N], [0i16; N], [0u8; 512]);
    unsafe { tc_compute(h.as_ptr(), l.as_ptr(), k.as_ptr(), i.as_ptr(), out.as_mut_ptr(), enc.as_mut_ptr(), N as i32); }
    let mut drv: Box<dyn TcuDriver> = Box::new(SerialTcu { path: "/dev/ttyACM0", dev: None });
    drv.open()?;
    let len = unsafe { tcu_encode(drv.header().as_ptr(), drv.header().len(), enc.as_ptr(), N as u16, frame.as_mut_ptr()) };
    drv.write_frame(&frame[..len])?;
    println!("{} : {} octets envoyés", drv.name(), len);
    Ok(())
}
` },
  { id: "zig", file: "mmio.zig", lang: "Zig", code: `const std = @import("std");

pub const Regs = extern struct {
    ctrl: u32, status: u32, _r0: [2]u32,
    dma_src_lo: u32, dma_src_hi: u32, dma_len: u32,
};

export fn mmio_map(path: [*:0]const u8, size: usize) ?*anyopaque {
    const fd = std.posix.openZ(path, .{ .ACCMODE = .RDWR, .SYNC = true }, 0) catch return null;
    defer std.posix.close(fd);
    const m = std.posix.mmap(null, size, std.posix.PROT.READ | std.posix.PROT.WRITE,
        .{ .TYPE = .SHARED }, fd, 0) catch return null;
    return @ptrCast(m.ptr);
}

export fn mmio_write32(base: *anyopaque, off: usize, v: u32) void {
    const p: *volatile u32 = @ptrFromInt(@intFromPtr(base) + off);
    p.* = v;
}

export fn mmio_read32(base: *anyopaque, off: usize) u32 {
    const p: *volatile u32 = @ptrFromInt(@intFromPtr(base) + off);
    return p.*;
}
` },
];
