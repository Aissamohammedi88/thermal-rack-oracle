import { useSyncExternalStore } from "react";
import type { SimParams } from "./thermal";

interface State extends SimParams { tick: number; running: boolean; selected: { r: number; c: number } }
let state: State = { heat: 12000, material: "copper", thicknessMm: 5, failedAt: [null, null, null, null], tick: 0, running: true, selected: { r: 1, c: 5 } };
const subs = new Set<() => void>();
export function setSim(p: Partial<State> | ((s: State) => Partial<State>)) {
  state = { ...state, ...(typeof p === "function" ? p(state) : p) };
  subs.forEach((f) => f());
}
const subscribe = (f: () => void) => { subs.add(f); return () => subs.delete(f); };
export const useSim = () => useSyncExternalStore(subscribe, () => state, () => state);
export function startClock() {
  const id = setInterval(() => { if (state.running) setSim((s) => ({ tick: s.tick + 1 })); }, 500);
  return () => clearInterval(id);
}
