import { crc32 } from "./thermal";

export interface TcuFamily {
  id: string; name: string; bus: string; throughput: string; latency: string;
  header: number[]; maxPayload: number; registers: { addr: string; name: string; desc: string }[];
  wiring: string[]; vendorRef: string; linuxIf: string;
}

export const FAMILIES: TcuFamily[] = [
  { id: "pcie", name: "PCIe Direct Memory", bus: "DMA / BAR Registers", throughput: "15.75 GB/s (Gen4 x8)", latency: "< 1 µs", header: [0x50, 0xc1], maxPayload: 4096, linuxIf: "/sys/bus/pci/devices/0000:3b:00.0/resource0", vendorRef: "TCU-PCIE-G4X8",
    registers: [{ addr: "BAR0+0x0000", name: "CTRL", desc: "Contrôle global / reset" }, { addr: "BAR0+0x0004", name: "STATUS", desc: "État DMA / IRQ" }, { addr: "BAR0+0x0010", name: "DMA_SRC_LO", desc: "Adresse source basse" }, { addr: "BAR0+0x0018", name: "DMA_LEN", desc: "Longueur transfert" }, { addr: "BAR2+0x1000", name: "TEMP_MATRIX", desc: "Fenêtre matrice 42×48" }],
    wiring: ["Slot PCIe x8 CPU0", "Alim 12V auxiliaire 6-pin", "Pont SMBus PCIe pour télémétrie", "Riser blindé ≤ 20 cm"] },
  { id: "usb", name: "USB CDC-ACM / FTDI", bus: "USB 2.0 High-Speed", throughput: "480 Mb/s (≈ 35 MB/s eff.)", latency: "125 µs (µframe)", header: [0x55, 0xab], maxPayload: 512, linuxIf: "/dev/ttyACM0", vendorRef: "TCU-USB-FT232H",
    registers: [{ addr: "EP0", name: "CTRL_EP", desc: "Requêtes de contrôle" }, { addr: "EP1 IN", name: "TELEM", desc: "Remontée télémétrie" }, { addr: "EP2 OUT", name: "CMD", desc: "Commandes/payload" }, { addr: "0x40", name: "BAUD_DIV", desc: "Diviseur FTDI" }],
    wiring: ["Câble USB-C blindé ≤ 2 m", "Ferrite côté hôte", "VBUS isolé (ADuM3160)", "GND châssis commun"] },
  { id: "spi", name: "SPI Haute Fréquence", bus: "spidev mode 0/3", throughput: "50 Mb/s @ 50 MHz", latency: "~ 2 µs", header: [0x5a], maxPayload: 256, linuxIf: "/dev/spidev0.0", vendorRef: "TCU-SPI-HF50",
    registers: [{ addr: "0x00", name: "WHOAMI", desc: "ID puce (0xTC)" }, { addr: "0x01", name: "CFG", desc: "Mode / CPOL / CPHA" }, { addr: "0x10", name: "FIFO_TX", desc: "FIFO écriture 256 o" }, { addr: "0x20", name: "THRESH", desc: "Seuils d'alerte" }],
    wiring: ["SCLK / MOSI / MISO / CS# en paires torsadées", "Résistances série 33 Ω", "Longueur ≤ 15 cm", "Plan de masse continu"] },
  { id: "i2c", name: "I2C / SMBus", bus: "Fond de panier 400 kHz / 1 MHz", throughput: "1 Mb/s (Fm+)", latency: "~ 100 µs", header: [0x48 << 1], maxPayload: 32, linuxIf: "/dev/i2c-1 @ 0x48", vendorRef: "TCU-I2C-BP8",
    registers: [{ addr: "0x00", name: "TEMP", desc: "Température 13 bits" }, { addr: "0x01", name: "CONFIG", desc: "Résolution / mode" }, { addr: "0x02", name: "T_LOW", desc: "Seuil bas" }, { addr: "0x03", name: "T_HIGH", desc: "Seuil haut / ALERT#" }],
    wiring: ["SDA / SCL pull-up 2.2 kΩ à 3.3 V", "ALERT# open-drain", "Max 8 sondes / segment", "Multiplexeur TCA9548A au-delà"] },
  { id: "rdma", name: "Ethernet RDMA / RoCE v2", bus: "SmartNIC / DPU 100GbE", throughput: "100 Gb/s", latency: "~ 1.5 µs", header: [0x12, 0xb7], maxPayload: 4096, linuxIf: "mlx5_0 port 1 (UDP 4791)", vendorRef: "TCU-DPU-ROCE2",
    registers: [{ addr: "QP 0x11", name: "QPN", desc: "Queue Pair dédiée" }, { addr: "MR 0x2000", name: "MEM_REG", desc: "Région mémoire enregistrée" }, { addr: "CQ 0x3", name: "COMPL_Q", desc: "File de complétion" }, { addr: "PFC 3", name: "PRIO", desc: "Priorité lossless" }],
    wiring: ["QSFP28 DAC ≤ 3 m ou AOC", "Switch avec PFC/ECN", "MTU 4200 (jumbo)", "VLAN télémétrie dédié"] },
  { id: "uart", name: "UART / RS-485 Industriel", bus: "Modbus RTU semi-duplex", throughput: "921.6 kb/s", latency: "~ 1 ms", header: [0x01, 0x10], maxPayload: 252, linuxIf: "/dev/ttyS1 (RS485 ioctl)", vendorRef: "TCU-485-ISO",
    registers: [{ addr: "40001", name: "HOLD_TEMP", desc: "Registre maintien temp." }, { addr: "40010", name: "SETPOINT", desc: "Consigne" }, { addr: "30001", name: "INPUT_RAW", desc: "Entrée brute ADC" }, { addr: "00001", name: "COIL_FAN", desc: "Commande ventilateur" }],
    wiring: ["Paire torsadée blindée 120 Ω", "Terminaisons 120 Ω aux 2 extrémités", "Polarisation 680 Ω", "Topologie bus, pas d'étoile"] },
  { id: "can", name: "SocketCAN / CAN-FD", bus: "CAN-FD 1/5 Mb/s", throughput: "5 Mb/s (phase données)", latency: "~ 200 µs", header: [0x18, 0xff], maxPayload: 64, linuxIf: "can0 (ip link type can fd on)", vendorRef: "TCU-CANFD-5M",
    registers: [{ addr: "0x18FF0100", name: "TEMP_ID", desc: "ID étendu télémétrie" }, { addr: "0x18FF0200", name: "CMD_ID", desc: "ID commande" }, { addr: "BTR", name: "BITTIMING", desc: "Timing nominal/données" }, { addr: "ESR", name: "ERR_STATUS", desc: "Compteurs erreurs" }],
    wiring: ["CAN_H / CAN_L paire torsadée 120 Ω", "Terminaisons 120 Ω", "Stub ≤ 30 cm", "Transceiver TCAN1042"] },
  { id: "axi", name: "AXI4-Stream / AXI-Lite", bus: "SoC / FPGA", throughput: "12.8 GB/s (256 bit @ 400 MHz)", latency: "< 100 ns", header: [0xa4, 0x1f], maxPayload: 4096, linuxIf: "/dev/uio0 (0xA0000000)", vendorRef: "TCU-AXI-ZU",
    registers: [{ addr: "0x00", name: "AP_CTRL", desc: "Start / done / idle" }, { addr: "0x10", name: "TDATA_CFG", desc: "Largeur TDATA" }, { addr: "0x18", name: "TLAST_CNT", desc: "Paquets transmis" }, { addr: "0x20", name: "IRQ_EN", desc: "Interruptions" }],
    wiring: ["Interconnexion AXI SmartConnect", "Horloges PL 100/400 MHz", "Reset synchrone actif bas", "DMA AXI vers PS DDR"] },
];

/** Encode temperatures (°C) as int16 centi-degrees little-endian, with family header, length and CRC32. */
export function encodeFrame(fam: TcuFamily, temps: number[]): Uint8Array {
  const n = Math.min(temps.length, Math.floor((fam.maxPayload - 4) / 2));
  const body = new Uint8Array(n * 2);
  const dv = new DataView(body.buffer);
  for (let i = 0; i < n; i++) dv.setInt16(i * 2, Math.round(temps[i]! * 100), true);
  const head = new Uint8Array([...fam.header, n & 0xff, (n >> 8) & 0xff]);
  const pre = new Uint8Array(head.length + body.length);
  pre.set(head); pre.set(body, head.length);
  const crc = crc32(pre);
  const out = new Uint8Array(pre.length + 4);
  out.set(pre);
  new DataView(out.buffer).setUint32(pre.length, crc, true);
  return out;
}

export function verifyFrame(frame: Uint8Array): boolean {
  if (frame.length < 5) return false;
  const pre = frame.slice(0, frame.length - 4);
  const crc = new DataView(frame.buffer, frame.byteOffset).getUint32(frame.length - 4, true);
  return crc32(pre) === crc;
}
