export const MATERIALS = {
  copper: { label: "Cuivre", k: 401 },
  aluminium: { label: "Aluminium", k: 237 },
  graphene: { label: "Graphène", k: 1500 },
  paste: { label: "Pâte thermique", k: 8.5 },
} as const;
export type MaterialId = keyof typeof MATERIALS;

/** Kernel CUDA: ΔT = (heat * thick) / cond — q en W/m², L en m, k en W/m·K */
export function deltaT(heat: number, thick: number, cond: number): number {
  if (cond <= 0) return Infinity;
  return (heat * thick) / cond;
}

export const ROWS = 4;
export const RACKS_PER_ROW = 12;
export const UNITS = 42;
/** CRAC positions in grid coordinates (row, col) */
export const CRACS = [
  { id: "CRAC-A", r: 0.5, c: -1 },
  { id: "CRAC-B", r: 2.5, c: -1 },
  { id: "CRAC-C", r: 0.5, c: RACKS_PER_ROW },
  { id: "CRAC-D", r: 2.5, c: RACKS_PER_ROW },
];

export interface SimParams {
  heat: number; // W/m²
  material: MaterialId;
  thicknessMm: number;
  failedAt: (number | null)[]; // tick of failure per CRAC
}

export function hotspot(r: number, c: number, p: SimParams, tick: number): number {
  let h = 0;
  p.failedAt.forEach((t0, i) => {
    if (t0 === null) return;
    const el = Math.max(0, tick - t0);
    const crac = CRACS[i]!;
    const d = Math.hypot(r - crac.r, (c - crac.c) * 0.6);
    const radius = 1.5 + el * 0.15;
    h += 18 * (1 - Math.exp(-el / 25)) * Math.exp(-d / radius);
  });
  return h;
}

export function rackUnitTemps(r: number, c: number, p: SimParams, tick: number): number[] {
  const inlet = 21 + hotspot(r, c, p, tick);
  const dt = deltaT(p.heat, p.thicknessMm / 1000, MATERIALS[p.material].k);
  const load = 0.6 + 0.4 * Math.abs(Math.sin(r * 3.1 + c * 1.7));
  return Array.from({ length: UNITS }, (_, u) => {
    const noise = Math.sin(tick * 0.3 + u * 0.7 + c) * 0.4;
    const strat = (u / UNITS) * 4; // stratification: hotter at top
    return inlet + strat + dt * load * (0.7 + 0.3 * Math.abs(Math.sin(u * 0.9 + c))) + noise;
  });
}

export function rackMax(r: number, c: number, p: SimParams, tick: number) {
  return Math.max(...rackUnitTemps(r, c, p, tick));
}

export function tempColor(t: number): string {
  const x = Math.min(1, Math.max(0, (t - 20) / 45));
  const hue = 240 - x * 240;
  return `oklch(${0.55 + x * 0.15} 0.2 ${hue})`;
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
export function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (const b of bytes) c = CRC_TABLE[(c ^ b) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

export const toHex = (b: Uint8Array) =>
  Array.from(b, (x) => x.toString(16).padStart(2, "0").toUpperCase()).join(" ");
