import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Panel } from "@/components/AppShell";
import { FAMILIES } from "@/lib/tcu";

export const Route = createFileRoute("/tcu")({
  head: () => ({ meta: [
    { title: "HAL & familles TCU — ThermaCore NOC" },
    { name: "description", content: "Spécifications, registres MMIO, débits et câblage des 8 familles de puces TCU." },
    { property: "og:title", content: "HAL & familles TCU — ThermaCore NOC" },
    { property: "og:description", content: "Gestionnaire des 8 architectures TCU." },
  ] }),
  component: TcuPage,
});

function TcuPage() {
  const [id, setId] = useState(FAMILIES[0]!.id);
  const [enabled, setEnabled] = useState<Record<string, boolean>>({ pcie: true, i2c: true });
  const f = FAMILIES.find((x) => x.id === id)!;
  return (
    <div className="grid gap-4 lg:grid-cols-[300px_1fr]">
      <Panel title="8 familles TCU">
        <div className="space-y-1">
          {FAMILIES.map((x, i) => (
            <button key={x.id} onClick={() => setId(x.id)} className={`flex w-full items-center gap-2 rounded border px-2 py-1.5 text-left text-sm ${id === x.id ? "border-primary bg-primary/10" : "border-border hover:bg-secondary"}`}>
              <span className="font-mono text-xs text-muted-foreground">{i + 1}</span>
              <span className="flex-1"><b>{x.name}</b><span className="block text-xs text-muted-foreground">{x.bus}</span></span>
              <span className={`h-2 w-2 rounded-full ${enabled[x.id] ? "bg-success" : "bg-muted-foreground/40"}`} />
            </button>
          ))}
        </div>
      </Panel>
      <div className="space-y-4">
        <Panel title={`Configuration · ${f.name}`}>
          <div className="grid gap-3 md:grid-cols-4">
            {[["Bus", f.bus], ["Débit", f.throughput], ["Latence", f.latency], ["Payload max", `${f.maxPayload} o`], ["Interface Linux", f.linuxIf], ["Réf. commande", f.vendorRef], ["En-tête trame", f.header.map((h) => "0x" + h.toString(16).toUpperCase().padStart(2, "0")).join(" ")]].map(([k, v]) => (
              <div key={k} className="rounded bg-muted p-2"><div className="text-xs text-muted-foreground">{k}</div><div className="font-mono text-sm text-primary break-all">{v}</div></div>
            ))}
            <button onClick={() => setEnabled((e) => ({ ...e, [f.id]: !e[f.id] }))} className={`rounded border p-2 font-semibold ${enabled[f.id] ? "border-success text-success" : "border-border text-muted-foreground"}`}>
              {enabled[f.id] ? "● Pilote HAL actif" : "○ Activer le pilote"}
            </button>
          </div>
        </Panel>
        <Panel title="Registres MMIO / carte mémoire">
          <table className="w-full font-mono text-sm">
            <thead><tr className="text-left text-xs text-muted-foreground"><th className="py-1">Adresse</th><th>Nom</th><th>Description</th></tr></thead>
            <tbody>{f.registers.map((r) => <tr key={r.addr} className="border-t border-border"><td className="py-1 text-accent">{r.addr}</td><td className="text-primary">{r.name}</td><td className="font-sans">{r.desc}</td></tr>)}</tbody>
          </table>
        </Panel>
        <Panel title="Schéma de câblage (bon de commande fournisseur)">
          <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
            <div className="rounded border border-primary px-3 py-4 text-primary">HÔTE<br />Linux Mint</div>
            {f.wiring.map((w, i) => (<div key={i} className="flex items-center gap-2"><span className="text-muted-foreground">━━▶</span><div className="max-w-40 rounded border border-border bg-muted px-2 py-2">{w}</div></div>))}
            <span className="text-muted-foreground">━━▶</span>
            <div className="rounded border border-accent px-3 py-4 text-accent">{f.vendorRef}</div>
          </div>
        </Panel>
      </div>
    </div>
  );
}
