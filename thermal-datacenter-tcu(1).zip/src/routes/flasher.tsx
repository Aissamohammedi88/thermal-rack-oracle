import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Panel } from "@/components/AppShell";
import { useSim } from "@/lib/sim-store";
import { FAMILIES, encodeFrame, verifyFrame } from "@/lib/tcu";
import { rackUnitTemps, toHex, crc32 } from "@/lib/thermal";

export const Route = createFileRoute("/flasher")({
  head: () => ({ meta: [
    { title: "Générateur de payload & Flasher — ThermaCore NOC" },
    { name: "description", content: "Encodage des matrices de température en trames binaires avec CRC32 et flashage TCU." },
    { property: "og:title", content: "Payload & Flasher TCU — ThermaCore NOC" },
    { property: "og:description", content: "Console de transmission TCU en direct." },
  ] }),
  component: FlasherPage,
});

type Log = { t: string; dir: "TX" | "RX" | "SYS" | "ERR"; msg: string };

function FlasherPage() {
  const s = useSim();
  const [famId, setFamId] = useState("pcie");
  const [corrupt, setCorrupt] = useState(false);
  const [logs, setLogs] = useState<Log[]>([]);
  const [flashing, setFlashing] = useState<number | null>(null);
  const [stats, setStats] = useState({ tx: 0, ok: 0, err: 0 });
  const fam = FAMILIES.find((f) => f.id === famId)!;
  const temps = rackUnitTemps(s.selected.r, s.selected.c, s, s.tick);
  const frame = encodeFrame(fam, temps);
  const ref = useRef<HTMLDivElement>(null);
  const log = (dir: Log["dir"], msg: string) => setLogs((l) => [...l.slice(-200), { t: new Date().toISOString().slice(11, 23), dir, msg }]);
  useEffect(() => { ref.current?.scrollTo(0, ref.current.scrollHeight); }, [logs]);

  const transmit = () => {
    const f = frame.slice();
    if (corrupt) f[5] = (f[5] ?? 0) ^ 0xff;
    const ok = verifyFrame(f);
    log("TX", `${fam.linuxIf} ← ${f.length} o · CRC32=0x${crc32(f.slice(0, -4)).toString(16).toUpperCase().padStart(8, "0")}`);
    log(ok ? "RX" : "ERR", ok ? `ACK ${fam.vendorRef} · CRC vérifié` : `NAK · CRC32 invalide, retransmission requise`);
    setStats((st) => ({ tx: st.tx + 1, ok: st.ok + (ok ? 1 : 0), err: st.err + (ok ? 0 : 1) }));
  };
  const flash = () => {
    setFlashing(0); log("SYS", `Début flashage registres ${fam.name}`);
    fam.registers.forEach((r, i) => setTimeout(() => {
      const val = (crc32(new TextEncoder().encode(r.name + s.tick)) >>> 0).toString(16).toUpperCase().padStart(8, "0");
      log("TX", `WRITE ${r.addr} (${r.name}) ← 0x${val}`);
      log("RX", `READBACK ${r.addr} = 0x${val} ✓`);
      setFlashing(((i + 1) / fam.registers.length) * 100);
      if (i === fam.registers.length - 1) { log("SYS", "Flashage terminé · intégrité OK"); setTimeout(() => setFlashing(null), 800); }
    }, (i + 1) * 400));
  };
  const color = { TX: "text-primary", RX: "text-success", SYS: "text-accent", ERR: "text-destructive" };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
      <div className="space-y-4">
        <Panel title="Générateur de payload">
          <div className="flex flex-wrap gap-2 text-sm">
            <select value={famId} onChange={(e) => setFamId(e.target.value)} className="rounded border border-border bg-background px-2 py-1">
              {FAMILIES.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
            </select>
            <span className="self-center font-mono text-xs text-muted-foreground">Source : rack R{s.selected.r + 1}-{s.selected.c + 1} · 42U · int16 c°C LE</span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 font-mono text-xs">
            <div className="rounded bg-muted p-2">Taille<div className="text-lg text-primary">{frame.length} o</div></div>
            <div className="rounded bg-muted p-2">En-tête<div className="text-lg text-accent">{toHex(frame.slice(0, fam.header.length + 2))}</div></div>
            <div className="rounded bg-muted p-2">CRC32<div className="text-lg text-success">{toHex(frame.slice(-4))}</div></div>
          </div>
          <pre className="mt-3 max-h-64 overflow-auto rounded bg-background p-2 font-mono text-[11px] leading-5">
            {Array.from({ length: Math.ceil(frame.length / 16) }, (_, i) => (
              <div key={i}><span className="text-muted-foreground">{(i * 16).toString(16).padStart(4, "0")}  </span>{toHex(frame.slice(i * 16, i * 16 + 16))}</div>
            ))}
          </pre>
        </Panel>
        <Panel title="Actions">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={transmit} className="rounded bg-primary px-4 py-2 font-semibold text-primary-foreground hover:bg-primary/90">▶ Transmettre la trame</button>
            <button onClick={flash} disabled={flashing !== null} className="rounded border border-accent px-4 py-2 font-semibold text-accent hover:bg-accent/10 disabled:opacity-50">⚡ Flasher les registres</button>
            <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={corrupt} onChange={(e) => setCorrupt(e.target.checked)} /> Injecter une corruption</label>
          </div>
          {flashing !== null && <div className="mt-3 h-2 rounded bg-muted"><div className="h-2 rounded bg-accent transition-all" style={{ width: `${flashing}%` }} /></div>}
        </Panel>
      </div>
      <Panel title="Console E/S en direct">
        <div className="mb-2 flex gap-4 font-mono text-xs"><span>TX {stats.tx}</span><span className="text-success">OK {stats.ok}</span><span className="text-destructive">ERR {stats.err}</span>
          <button onClick={() => setLogs([])} className="ml-auto text-muted-foreground hover:text-foreground">effacer</button></div>
        <div ref={ref} className="h-[560px] overflow-auto rounded bg-background p-2 font-mono text-xs leading-5">
          {logs.length === 0 && <div className="text-muted-foreground">$ en attente de transmission…</div>}
          {logs.map((l, i) => <div key={i}><span className="text-muted-foreground">{l.t} </span><span className={color[l.dir]}>[{l.dir}]</span> {l.msg}</div>)}
        </div>
      </Panel>
    </div>
  );
}
