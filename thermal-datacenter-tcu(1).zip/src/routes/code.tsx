import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Panel } from "@/components/AppShell";
import { SOURCES } from "@/lib/sources";

export const Route = createFileRoute("/code")({
  head: () => ({ meta: [
    { title: "Hub d'intégration & code source — ThermaCore NOC" },
    { name: "description", content: "Script d'orchestration Linux Mint et modules CUDA, C11, Rust et Zig exportables." },
    { property: "og:title", content: "Hub d'intégration — ThermaCore NOC" },
    { property: "og:description", content: "Code source prêt à l'emploi pour les TCU." },
  ] }),
  component: CodePage,
});

function download(name: string, code: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([code], { type: "text/plain" }));
  a.download = name.split("/").pop()!; a.click();
}

function CodePage() {
  const [id, setId] = useState("bash");
  const [copied, setCopied] = useState(false);
  const src = SOURCES.find((s) => s.id === id)!;
  return (
    <Panel title="Hub d'intégration système">
      <div className="mb-3 flex flex-wrap gap-1">
        {SOURCES.map((s) => (
          <button key={s.id} onClick={() => setId(s.id)} className={`rounded border px-3 py-1 text-sm font-semibold ${id === s.id ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-secondary"}`}>
            {s.lang} <span className="font-mono text-xs text-muted-foreground">{s.file}</span>
          </button>
        ))}
        <div className="ml-auto flex gap-1">
          <button onClick={() => { navigator.clipboard.writeText(src.code); setCopied(true); setTimeout(() => setCopied(false), 1200); }} className="rounded border border-border px-3 py-1 text-sm hover:bg-secondary">{copied ? "Copié ✓" : "Copier"}</button>
          <button onClick={() => download(src.file, src.code)} className="rounded bg-primary px-3 py-1 text-sm font-semibold text-primary-foreground">Exporter</button>
          <button onClick={() => SOURCES.forEach((s, i) => setTimeout(() => download(s.file, s.code), i * 200))} className="rounded border border-accent px-3 py-1 text-sm text-accent">Tout exporter</button>
        </div>
      </div>
      <pre className="max-h-[70vh] overflow-auto rounded bg-background p-3 font-mono text-xs leading-5">
        {src.code.split("\n").map((l, i) => <div key={i}><span className="mr-3 inline-block w-8 select-none text-right text-muted-foreground">{i + 1}</span>{l}</div>)}
      </pre>
    </Panel>
  );
}
