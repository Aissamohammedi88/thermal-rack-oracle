import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Panel } from "@/components/AppShell";
import { SimControls, Gauge } from "@/components/Controls";
import { useSim } from "@/lib/sim-store";
import { RACKS_PER_ROW, ROWS, rackMax, tempColor } from "@/lib/thermal";

export const Route = createFileRoute("/simulation")({
  head: () => ({ meta: [
    { title: "Moteur de simulation — ThermaCore NOC" },
    { name: "description", content: "Charge thermique, matériaux, pannes CRAC et propagation des points chauds." },
    { property: "og:title", content: "Moteur de simulation — ThermaCore NOC" },
    { property: "og:description", content: "Simulation en direct de pannes de climatisation." },
  ] }),
  component: SimPage,
});

function SimPage() {
  const s = useSim();
  const all: number[] = [];
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < RACKS_PER_ROW; c++) all.push(rackMax(r, c, s, s.tick));
  const peak = Math.max(...all), avg = all.reduce((a, b) => a + b, 0) / all.length;
  const hot = all.filter((t) => t > 45).length;
  const [hist, setHist] = useState<{ peak: number; avg: number }[]>([]);
  const last = useRef(-1);
  useEffect(() => {
    if (last.current === s.tick) return;
    last.current = s.tick;
    setHist((h) => [...h.slice(-119), { peak, avg }]);
  }, [s.tick, peak, avg]);
  const line = (k: "peak" | "avg") => hist.map((p, i) => `${(i / 119) * 600},${150 - ((p[k] - 15) / 60) * 140}`).join(" ");
  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <Panel title="Pic salle"><Gauge value={peak} label="°C max" /></Panel>
          <Panel title="Moyenne"><Gauge value={avg} label="°C moy." /></Panel>
          <Panel title="Hotspots"><div className={`text-center font-mono text-4xl ${hot ? "text-destructive" : "text-success"}`}>{hot}</div><div className="text-center text-xs text-muted-foreground">racks &gt; 45°C</div></Panel>
          <Panel title="Statut"><div className={`text-center font-mono text-xl font-semibold ${peak > 55 ? "animate-pulse text-destructive" : peak > 40 ? "text-accent" : "text-success"}`}>{peak > 55 ? "CRITIQUE" : peak > 40 ? "VIGILANCE" : "NOMINAL"}</div></Panel>
        </div>
        <Panel title="Télémétrie temps réel (60 s)">
          <svg viewBox="0 0 600 150" className="h-48 w-full" preserveAspectRatio="none">
            {[25, 40, 55].map((t) => <line key={t} x1="0" x2="600" y1={150 - ((t - 15) / 60) * 140} y2={150 - ((t - 15) / 60) * 140} stroke="var(--border)" strokeDasharray="4 4" />)}
            <polyline fill="none" stroke="var(--destructive)" strokeWidth="2" points={line("peak")} />
            <polyline fill="none" stroke="var(--primary)" strokeWidth="2" points={line("avg")} />
          </svg>
          <div className="flex gap-4 font-mono text-xs"><span className="text-destructive">— pic</span><span className="text-primary">— moyenne</span></div>
        </Panel>
        <Panel title="Propagation des points chauds (heatmap continue)">
          <div className="grid gap-px" style={{ gridTemplateColumns: `repeat(${RACKS_PER_ROW}, 1fr)` }}>
            {all.map((t, i) => <div key={i} className="h-10 transition-colors duration-500" style={{ background: tempColor(t), opacity: 0.9 }} title={`${t.toFixed(1)}°C`} />)}
          </div>
        </Panel>
      </div>
      <SimControls />
    </div>
  );
}
