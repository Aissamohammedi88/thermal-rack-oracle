import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Panel } from "@/components/AppShell";
import { SimControls, Gauge } from "@/components/Controls";
import { setSim, useSim } from "@/lib/sim-store";
import { CRACS, RACKS_PER_ROW, ROWS, UNITS, rackMax, rackUnitTemps, tempColor, deltaT, MATERIALS } from "@/lib/thermal";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Cartographie thermique — ThermaCore NOC" },
    { name: "description", content: "Plan 2D/3D des allées chaudes et froides avec heatmap des racks en temps réel." },
    { property: "og:title", content: "Cartographie thermique — ThermaCore NOC" },
    { property: "og:description", content: "Heatmap temps réel des racks du data center." },
  ] }),
  component: MapPage,
});

function MapPage() {
  const s = useSim();
  const [iso, setIso] = useState(false);
  const rows = Array.from({ length: ROWS }, (_, r) => r);
  const temps = rackUnitTemps(s.selected.r, s.selected.c, s, s.tick);
  const max = Math.max(...temps), min = Math.min(...temps);
  const dt = deltaT(s.heat, s.thicknessMm / 1000, MATERIALS[s.material].k);
  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
      <div className="space-y-4">
        <Panel title="Salle serveurs — plan des allées">
          <div className="mb-2 flex items-center gap-2 text-xs">
            <button onClick={() => setIso(false)} className={`rounded border px-2 py-0.5 ${!iso ? "border-primary text-primary" : "border-border"}`}>Vue 2D</button>
            <button onClick={() => setIso(true)} className={`rounded border px-2 py-0.5 ${iso ? "border-primary text-primary" : "border-border"}`}>Vue 3D</button>
            <span className="ml-auto flex items-center gap-1 font-mono text-muted-foreground">20°C
              <span className="h-2 w-32 rounded" style={{ background: `linear-gradient(90deg, ${[20, 31, 42, 53, 65].map(tempColor).join(",")})` }} />65°C</span>
          </div>
          <div className="overflow-x-auto py-4" style={{ perspective: 1200 }}>
            <div className="mx-auto w-fit transition-transform duration-500" style={{ transform: iso ? "rotateX(55deg) rotateZ(-30deg)" : "none", transformStyle: "preserve-3d" }}>
              {rows.map((r) => (
                <div key={r}>
                  {r % 2 === 0 && <Aisle kind="cold" />}
                  <div className="flex items-center gap-1">
                    <Crac on={r === 0 || r === 2} idx={r} side="L" />
                    {Array.from({ length: RACKS_PER_ROW }, (_, c) => {
                      const t = rackMax(r, c, s, s.tick);
                      const sel = s.selected.r === r && s.selected.c === c;
                      return (
                        <button key={c} onClick={() => setSim({ selected: { r, c } })} title={`R${r + 1}-${c + 1} · ${t.toFixed(1)}°C`}
                          className={`relative h-14 w-10 rounded-sm border font-mono text-[9px] text-primary-foreground transition-colors ${sel ? "border-foreground ring-2 ring-primary" : "border-background"}`}
                          style={{ background: tempColor(t), transform: iso ? `translateZ(${(t - 20) * 0.8}px)` : undefined, boxShadow: iso ? `0 0 0 1px var(--background), 0 ${(t - 20) * 0.5}px ${(t - 20)}px -4px ${tempColor(t)}` : undefined }}>
                          {t.toFixed(0)}
                        </button>
                      );
                    })}
                    <Crac on={r === 0 || r === 2} idx={r + 2 > 3 ? 3 : r === 0 ? 2 : 3} side="R" />
                  </div>
                  {r % 2 === 0 && <Aisle kind="hot" />}
                </div>
              ))}
              <Aisle kind="cold" />
            </div>
          </div>
        </Panel>
        <Panel title={`Gradient thermique — rack R${s.selected.r + 1}-${s.selected.c + 1}`}>
          <svg viewBox="0 0 420 100" className="h-40 w-full" preserveAspectRatio="none">
            <polyline fill="none" stroke="var(--primary)" strokeWidth="2"
              points={temps.map((t, u) => `${10 + u * 10},${90 - ((t - 15) / 60) * 80}`).join(" ")} />
            {temps.map((t, u) => <circle key={u} cx={10 + u * 10} cy={90 - ((t - 15) / 60) * 80} r="2" fill={tempColor(t)} />)}
            <text x="10" y="98" fontSize="7" fill="var(--muted-foreground)">1U</text>
            <text x="400" y="98" fontSize="7" fill="var(--muted-foreground)">42U</text>
          </svg>
        </Panel>
      </div>
      <div className="space-y-4">
        <Panel title={`Inspection rack R${s.selected.r + 1}-${s.selected.c + 1}`}>
          <div className="grid grid-cols-3 gap-2"><Gauge value={max} label="max" /><Gauge value={min} label="min" /><Gauge value={max - min} max={40} label="Δ vertical" /></div>
          <div className="mt-3 flex gap-3">
            <div className="flex flex-1 flex-col-reverse gap-px rounded border border-border bg-background p-1">
              {temps.map((t, u) => (
                <div key={u} className="flex h-3 items-center justify-between rounded-[1px] px-1 font-mono text-[8px] text-primary-foreground" style={{ background: tempColor(t) }}>
                  <span>{u + 1}U</span><span>{t.toFixed(1)}°C</span>
                </div>
              ))}
            </div>
          </div>
          <p className="mt-2 font-mono text-[11px] text-muted-foreground">ΔT conduction par unité : {dt.toFixed(3)} K · {UNITS}U</p>
        </Panel>
        <SimControls />
      </div>
    </div>
  );
}

function Aisle({ kind }: { kind: "cold" | "hot" }) {
  return <div className={`my-1 ml-11 h-4 rounded-sm text-center font-mono text-[9px] uppercase leading-4 tracking-[0.4em] ${kind === "cold" ? "bg-cold/25 text-cold" : "bg-hot/25 text-hot"}`}>{kind === "cold" ? "allée froide" : "allée chaude"}</div>;
}
function Crac({ on, idx, side }: { on: boolean; idx: number; side: string }) {
  const s = useSim();
  if (!on) return <div className="w-10" />;
  const i = side === "L" ? (idx === 0 ? 0 : 1) : idx;
  const down = s.failedAt[i] !== null;
  return <div className={`flex h-14 w-10 items-center justify-center rounded-sm border text-[8px] font-mono [writing-mode:vertical-rl] ${down ? "animate-pulse border-destructive bg-destructive/30 text-destructive" : "border-cold bg-cold/20 text-cold"}`}>{CRACS[i]!.id}</div>;
}
